import { useEffect, useState } from 'react';
import {
  ArrowDown,
  ArrowUpRight,
  Braces,
  Check,
  Code2,
  Compass,
  Layers3,
  Mail,
  Menu,
  MousePointer2,
  PenTool,
  Rocket,
  Sparkles,
  X,
} from 'lucide-react';

const projects = [
  {
    title: '[Project One]',
    category: '[Product design · Full-stack]',
    year: '[2025]',
    description: '[A concise summary of the product, the people it serves, and the problem you made easier.]',
    tags: ['React', 'TypeScript', '[Add stack]'],
    visual: 'ledger',
  },
  {
    title: '[Project Two]',
    category: '[Frontend · Data visualization]',
    year: '[2024]',
    description: '[Describe a useful interface you built and the specific moment it helped a user move forward.]',
    tags: ['Next.js', 'D3.js', '[Add stack]'],
    visual: 'atlas',
  },
  {
    title: '[Project Three]',
    category: '[Workflow · Product engineering]',
    year: '[2024]',
    description: '[Show how you turned a complicated workflow into a clear, dependable experience.]',
    tags: ['React', 'Node.js', '[Add stack]'],
    visual: 'field',
  },
  {
    title: '[Project Four]',
    category: '[Experiment · Developer tools]',
    year: '[2023]',
    description: '[A small tool, open-source contribution, or experiment that reflects how you like to think.]',
    tags: ['TypeScript', 'API design', '[Add stack]'],
    visual: 'signal',
  },
];

const process = [
  { number: '01', title: 'Find the signal', description: 'Get close to the real need. Ask better questions before adding more software.', Icon: Compass },
  { number: '02', title: 'Shape the idea', description: 'Make the hard parts visible, then map a path that feels simple to use.', Icon: PenTool },
  { number: '03', title: 'Build with care', description: 'Ship sturdy foundations, thoughtful details, and interfaces that make sense.', Icon: Code2 },
  { number: '04', title: 'Make it better', description: 'Learn from real use. Refine the rough edges and keep the product moving.', Icon: Rocket },
];

function ProjectVisual({ variant }: { variant: string }) {
  if (variant === 'atlas') {
    return (
      <div className="project-visual visual-atlas" aria-hidden="true">
        <div className="atlas-panel">
          <div className="atlas-map" />
          <div className="atlas-route" />
          <div className="atlas-pin">+</div>
          <div className="atlas-label">[A place worth finding]</div>
        </div>
      </div>
    );
  }
  if (variant === 'field') {
    return (
      <div className="project-visual visual-field" aria-hidden="true">
        <div className="field-board">
          <div className="field-head"><b /><i /></div>
          <div className="field-columns">
            {[0, 1, 2].map((column) => <div className="field-col" key={column}><div className="field-chip" /><div className="field-chip" /></div>)}
          </div>
        </div>
      </div>
    );
  }
  if (variant === 'signal') {
    return (
      <div className="project-visual visual-signal" aria-hidden="true">
        <div className="signal-screen">
          <div className="signal-number">[00.0]</div>
          <div className="signal-caption">[A useful measure, at a glance]</div>
          <div className="signal-bars">{[37, 52, 43, 70, 57, 81, 64, 95, 73, 88, 67].map((height, i) => <i style={{ '--h': `${height}%` } as React.CSSProperties} key={i} />)}</div>
        </div>
      </div>
    );
  }
  return (
    <div className="project-visual visual-ledger" aria-hidden="true">
      <div className="mock-window">
        <div className="mock-top"><i /><i /><i /></div>
        <div className="mock-body">
          <div className="mock-sidebar"><div className="mock-logo" /><div className="mock-navline active" /><div className="mock-navline" /><div className="mock-navline" /><div className="mock-navline" /></div>
          <div className="mock-content"><div className="mock-title" /><div className="mock-statrow"><div className="mock-stat" /><div className="mock-stat" /><div className="mock-stat" /></div><div className="mock-chart" /></div>
        </div>
      </div>
    </div>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [year] = useState(new Date().getFullYear());

  useEffect(() => {
    const nodes = document.querySelectorAll<HTMLElement>('.reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(''), 2300);
    return () => window.clearTimeout(timer);
  }, [toast]);

  const closeMenu = () => setMenuOpen(false);
  const copyEmail = async () => {
    const email = 'your.email@example.com';
    try {
      await navigator.clipboard.writeText(email);
      setToast('Email address copied to clipboard');
    } catch {
      window.location.href = `mailto:${email}`;
      setToast('Opening your email app');
    }
  };

  return (
    <div className="site-shell">
      <header className="topbar">
        <nav className="nav container" aria-label="Main navigation">
          <a className="brand" href="#top" onClick={closeMenu} data-testid="link-home">
            <span className="brand-mark">IRN</span>
            <span>ITOE RAUL NENDI</span>
          </a>
          <div className={`nav-links ${menuOpen ? 'open' : ''}`}>
            <a href="#work" onClick={closeMenu} data-testid="link-work">Selected work</a>
            <a href="#approach" onClick={closeMenu} data-testid="link-approach">Approach</a>
            <a href="#about" onClick={closeMenu} data-testid="link-about">About</a>
            <a href="#toolkit" onClick={closeMenu} data-testid="link-toolkit">Toolkit</a>
          </div>
          <a className="nav-cta" href="#contact" data-testid="link-contact-top">Let’s talk <ArrowUpRight aria-hidden="true" /></a>
          <button className="menu-toggle" type="button" aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} onClick={() => setMenuOpen(!menuOpen)} data-testid="button-menu">
            {menuOpen ? <X size={19} /> : <Menu size={19} />}
          </button>
        </nav>
      </header>

      <main>
        <section className="hero" id="top">
          <div className="container hero-grid">
            <div>
              <div className="eyebrow hero-kicker reveal">Software Engineering Student · Douala, Cameroon</div>
              <h1 className="display reveal delay-1">Ideas into <span className="line-two">things that <span className="highlight">work.</span></span></h1>
              <p className="hero-intro reveal delay-2"><strong>I’m ITOE RAUL NENDI,</strong> a software engineering student at St. Louis University in Bonamoussadi, Douala, Cameroon. I’m learning to turn ideas into clear, useful digital products through study and hands-on practice.</p>
              <div className="hero-actions reveal delay-3">
                <a className="button-primary" href="#work" data-testid="link-explore-work">Explore selected work <ArrowUpRight aria-hidden="true" /></a>
                <a className="text-link" href="#about" data-testid="link-more-about">A little about me <ArrowDown aria-hidden="true" /></a>
              </div>
              <div className="hero-note reveal delay-3"><span /> Studying at St. Louis University</div>
            </div>
            <div className="orbit-art reveal delay-2" aria-label="Abstract illustration of ideas taking shape">
              <div className="orbit-ring" /><div className="orbit-ring second" />
              <div className="orbit-center"><span>IRN</span></div>
              <div className="orbit-tag tag-one"><i /> idea → useful</div>
              <div className="orbit-tag tag-two"><i /> product-minded</div>
              <div className="orbit-tag tag-three"><i /> shipped with care</div>
              <span className="spark spark-one">✳</span><span className="spark spark-two">✳</span>
            </div>
          </div>
        </section>

        <div className="proof-strip">
          <div className="container proof-inner">
            <span className="proof-label">The work tends to live here</span>
            <span className="proof-item"><Layers3 /> Product interfaces</span>
            <span className="proof-item"><Braces /> Thoughtful engineering</span>
            <span className="proof-item"><MousePointer2 /> Useful details</span>
          </div>
        </div>

        <section className="section work-section" id="work">
          <div className="container">
            <div className="section-heading reveal">
              <div><span className="eyebrow">A few things I’ve made</span><h2>Selected work<span style={{ color: '#a3c749' }}>.</span></h2></div>
              <p>Small selection, big range. Each project is a place to replace the placeholder with your real story, decisions, and impact.</p>
            </div>
            <div className="work-grid">
              {projects.map((project, index) => (
                <article className={`project-card reveal ${index % 2 ? 'delay-1' : ''}`} key={project.title} data-testid={`card-project-${index + 1}`}>
                  <ProjectVisual variant={project.visual} />
                  <div className="project-info">
                    <div className="project-meta"><span>{project.category}</span><span>{project.year}</span></div>
                    <div className="project-title-row"><h3>{project.title}</h3><a className="project-arrow" href="#contact" aria-label={`Ask about ${project.title}`} data-testid={`link-project-${index + 1}`}><ArrowUpRight /></a></div>
                    <p>{project.description}</p>
                    <div className="tag-list">{project.tags.map((tag) => <span key={tag}>{tag}</span>)}</div>
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="manifesto" id="approach">
          <div className="container manifesto-inner">
            <div className="reveal"><span className="eyebrow">A point of view</span></div>
            <div className="manifesto-copy reveal delay-1">
              <h2>Good software doesn’t make people work harder to use it. <em>It gives their attention back.</em></h2>
              <p>That’s the bar I bring to a project. Understand what matters, remove the needless friction, then build something that feels obvious in the best possible way.</p>
            </div>
          </div>
        </section>

        <section className="section" aria-labelledby="process-heading">
          <div className="container">
            <div className="section-heading reveal">
              <div><span className="eyebrow">How I work</span><h2 id="process-heading">From thought<br />to shipped.</h2></div>
              <p>Clear communication, considered decisions, and a bias toward making the thing real.</p>
            </div>
            <div className="process-grid">
              {process.map(({ number, title, description, Icon }, index) => (
                <article className={`process-step reveal delay-${index}`} key={number}>
                  <span className="step-index">{number} / 04</span>
                  <span className="step-icon"><Icon aria-hidden="true" /></span>
                  <h3>{title}</h3><p>{description}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section about-section" id="about">
          <div className="container about-grid">
            <div className="portrait-card reveal" aria-label="Abstract portrait placeholder">
              <div className="portrait-art"><div className="portrait-shape" /><div className="portrait-head" /><div className="portrait-hair" /></div>
              <span className="portrait-caption">St. Louis University · Douala, Cameroon</span>
            </div>
            <div className="about-copy reveal delay-1">
              <span className="eyebrow">The person behind the pixels</span>
              <h2>Learning to build.<br /><span>Growing with purpose.</span></h2>
              <p>My name is ITOE RAUL NENDI, and I’m a software engineering student at St. Louis University in Bonamoussadi, Douala, Cameroon. I’m developing the skills to create useful, well-crafted software.</p>
              <p>My studies are helping me build a strong foundation in software engineering and problem-solving. I’m eager to keep learning and put that knowledge into practice through meaningful projects.</p>
              <div className="about-facts">
                <div><span className="fact-label">Studying at</span><span className="fact-value">St. Louis University</span></div>
                <div><span className="fact-label">Based in</span><span className="fact-value">Bonamoussadi, Douala, Cameroon</span></div>
              </div>
            </div>
          </div>
        </section>

        <section className="section" id="toolkit">
          <div className="container toolkit">
            <div className="toolkit-intro reveal">
              <span className="eyebrow">Tools, not trophies</span>
              <h2>The right tool<br />for the job.</h2>
              <p>I care less about chasing a stack and more about choosing technology that keeps the product understandable, resilient, and pleasant to change.</p>
            </div>
            <div className="toolkit-list reveal delay-1">
              <div className="toolkit-row"><strong>Frontend</strong><div><span>React</span><span>TypeScript</span><span>[Add tools]</span></div></div>
              <div className="toolkit-row"><strong>Backend</strong><div><span>Node.js</span><span>[Add language]</span><span>[Add tools]</span></div></div>
              <div className="toolkit-row"><strong>Product</strong><div><span>Prototyping</span><span>Systems thinking</span><span>Accessibility</span></div></div>
              <div className="toolkit-row"><strong>Always learning</strong><div><span>[A technology]</span><span>[A practice]</span></div></div>
            </div>
          </div>
        </section>

        <section className="contact-section" id="contact">
          <div className="container contact-grid">
            <div className="reveal">
              <span className="eyebrow">Have a good problem?</span>
              <h2>Let’s make<br />it useful.</h2>
              <p>Have a product to shape, a team to join, or an interesting question? I’m happy to hear what you’re thinking.</p>
            </div>
            <div className="contact-action reveal delay-1">
              <a className="contact-email" href="mailto:your.email@example.com" data-testid="link-email"><Mail aria-hidden="true" /> your.email@example.com <ArrowUpRight aria-hidden="true" /></a>
              <button className="contact-hint" type="button" onClick={copyEmail} data-testid="button-copy-email"><Check size={13} /> Copy email address</button>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container footer-inner">
          <span className="footer-brand">ITOE RAUL NENDI <Sparkles size={12} style={{ display: 'inline', color: '#c7ed52', verticalAlign: 'middle' }} /></span>
          <span className="footer-note">Software Engineering Student · © {year} · Douala, Cameroon</span>
          <a className="back-top" href="#top" data-testid="link-back-to-top">Back to top <ArrowUpRight /></a>
        </div>
      </footer>
      <div className={`toast ${toast ? 'show' : ''}`} role="status" aria-live="polite">{toast}</div>
    </div>
  );
}

export default App;
