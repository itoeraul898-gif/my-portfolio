ITOE RAUL NENDI — PORTFOLIO

OPENING ON A CHROMEBOOK
1. Extract this ZIP in the Files app.
2. Open the extracted folder.
3. Double-click index.html and choose Chrome if asked.

The portfolio page is self-contained in index.html, so you do not need to install anything. If you are offline, it uses the browser’s built-in font fallbacks.

The source/ folder contains editable project source files. The root index.html is the ready-to-open website.
